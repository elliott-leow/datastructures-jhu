package hw2;

import exceptions.IndexException;
import exceptions.LengthException;
import java.util.Iterator;
import java.util.NoSuchElementException;


/**
 * An implementation of an IndexedList designed for cases where
 * only a few positions have distinct values from the initial value.
 *
 * @param <T> Element type.
 */
public class SparseIndexedList<T> implements IndexedList<T> {

  private T defaultValue;
  private int size;

  private int length;

  private Node<T> head;

  /**
   * Constructs a new SparseIndexedList of length size
   * with default value of defaultValue.
   *
   * @param size Length of list, expected: size > 0.
   * @param defaultValue Default value to store in each slot.
   * @throws LengthException if size <= 0.
   */
  public SparseIndexedList(int size, T defaultValue) throws LengthException {
    if (size <= 0) {
      throw new LengthException();
    }
    this.defaultValue = defaultValue;
    this.size = size;
  }

  @Override
  public int length() {
    return size;
  }

  @Override
  public T get(int index) throws IndexException {
    if (index >= size || index < 0) {
      throw new IndexException();
    } else {
      Node<T> current = head;
      while (current != null) {
        if (current.index == index) {
          return current.data;
        }
        if (current.index > index) {
          break;
        }
        current = current.next;
      }
      return defaultValue;
    }
  }

  @Override
  public void put(int index, T value) throws IndexException {
    if (index < 0 || index >= size) {
      throw new IndexException();
    } else {
      Node<T> newNode = new Node<>(value, index);
      Node<T> current = head;
      //checkHead();
//      if (head == null) {
//        head = newNode;
//      } else if (head.index >= index) {
//        if (value.equals(defaultValue)) {
//          head = head.next;
//        } else {
//          head.data = value;
//        }
      if (modifyHead(index, newNode)) {
        while (current.index <= index) {
//          if (current.index > index) { //prepend
//            head = prepend(newNode, head);
//            //return;
//          } else
          if (current.next == null) { //append
            current.next = newNode;
            //return;
          } else if (current.index < index && current.next.index > index) { //insert
            current.next = insert(newNode, current);
            //return;
          } else {
            if (current.next.index == index) { //change current node
              if (defaultValue.equals(value)) {
                current.next = current.next.next;
              } else {
                current.next.data = value;

              }
              return;
            }
            current = current.next;
          }
        }
      }
    }
  }

  private boolean modifyHead(int index, Node<T> newNode) {
    if (head == null) {
      head = newNode;
      return false;
    } else if (head.index >= index) {
      if (newNode.data.equals(defaultValue)) {
        head = head.next;
      } else {
        head.data = newNode.data;
      }
      return false;
    }
    return true;
  }
  private Node<T> prepend(Node<T> newNode, Node<T> oldHead) {
    newNode.next = oldHead;
    return newNode;
  }

  private Node<T> insert(Node<T> newNode, Node<T> current) {
    newNode.next = current.next;
    return newNode;
  }

  @Override
  public Iterator<T> iterator() {
    return new SparseIndexedListIterator();
  }

  private class SparseIndexedListIterator implements Iterator<T> {
    Node<T> currentNode;
    private int cursor;

    SparseIndexedListIterator() {
      cursor = 0;
      currentNode = head;
    }

    @Override
    public boolean hasNext() {
      return cursor < size;
    }

    @Override
    public T next() throws NoSuchElementException {
      if (!hasNext()) {
        throw new NoSuchElementException();
      } else {
        T returnValue;

        if (currentNode != null && currentNode.index == cursor) {
          returnValue = currentNode.data;
          currentNode = currentNode.next; //if the current node index matches the cursor
        } else {
          returnValue = defaultValue; //if the current node index is greater than cursor or if it's null
        }
        //no case that current node index be less than cursor
        cursor++;
        return returnValue;
      }
    }
  }

  private static class Node<E> {
    private Node<E> next;
    private int index;
    private E data;

    Node(E data, int index) {
      this.data = data;
      this.index = index;
    }
  }
}
